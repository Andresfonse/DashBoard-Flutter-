import 'package:flutter/material.dart';

class MyTile extends StatelessWidget {
  const MyTile({Key? key, required this.a}) : super(key: key);
  final int a;

  get cont => a;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
          alignment: Alignment.center,
          height: 78,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                '../image/pic${a + 1}.jpg',
              ),
              alignment: Alignment.centerLeft,
            ),
            borderRadius: BorderRadius.circular(8),
            color: Colors.blue[400],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                ),
                child: const Icon(
                  Icons.shopping_cart_checkout,
                  color: Colors.black,
                ),
              ),
              Center(
                child: Column(
                  children: [
                    if (cont == 0) ...[
                      const Text(
                        'Reloj Marca Gucci de Bonac',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 1) ...[
                      const Text(
                        'Reloj Ancestral Egipicio',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 2) ...[
                      const Text(
                        'Reloj de Plata Versacce',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 3) ...[
                      const Text(
                        'Reloj De oro',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 4) ...[
                      const Text(
                        'Reloj de Ruby con decoraciones de diamantes',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 5) ...[
                      const Text(
                        'Reloj de Cuarzo Azul',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 6) ...[
                      const Text(
                        'Reloj Deportivo conmmecanismo Antihederente',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ] else if (cont == 7) ...[
                      const Text(
                        'Reloj Random',
                        style: TextStyle(
                            fontSize: 15, fontStyle: FontStyle.italic),
                      ),

                    ]else if (cont == 8)...[
                      const Text(
                        'Reloj de NATURALEZA',
                        style: TextStyle(
                          fontSize: 15, fontStyle: FontStyle.italic),
                      ),
                    ]else if (cont == 9)... [
                      const Text(
                        'Reloj de Ghandi',
                        style: TextStyle(
                          fontStyle: FontStyle.italic,fontSize: 15),
                      ),
                    ]else if(cont ==10)...[
                      const Text(
                        'Reloj de Esmeralda',
                        style: TextStyle(
                          fontSize: 15, fontStyle: FontStyle.italic),
                      )
                    ]
                  ],
                ),
              )
            ],
          )),
    );
  }
}
