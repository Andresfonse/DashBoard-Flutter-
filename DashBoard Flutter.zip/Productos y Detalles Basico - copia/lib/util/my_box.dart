import 'package:flutter/material.dart';

class MyBox extends StatelessWidget {
  final int index;
  const MyBox({Key? key, required this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('../image/pic${index + 1}.jpg',
            ),
            fit: BoxFit.cover,
          ),
          borderRadius: BorderRadius.circular(8),
              color: Colors.red[400],
        ),
      ),
    );
  }
}